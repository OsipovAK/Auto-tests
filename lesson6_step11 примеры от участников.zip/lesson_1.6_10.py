from selenium import webdriver
from selenium.webdriver.chrome.options import Options
import time
from datetime import datetime

chrome_options = Options()
chrome_options.add_argument("--window-size=1920, 1080")
chrome_options.add_argument("--headless")
chrome_options.add_argument("--no-sandbox")
chrome_options.add_argument("--disable-dev-shm-usage")

link_1 = "http://suninjuly.github.io/registration1.html"
link_2 = "http://suninjuly.github.io/registration2.html"

links = [link_1, link_2]

try:
    browser = webdriver.Chrome(chrome_options=chrome_options)
    for link in links:
        browser.get(link)
    #
    first_name = browser.find_element_by_xpath(
        '//*/div[@class="first_block"]/'
        'div[@class="form-group first_class"]/input'
    )
    last_name = browser.find_element_by_xpath(
        '//*/div[@class="first_block"]/'
        'div[@class="form-group second_class"]/input'
    )
    email = browser.find_element_by_xpath(
        '//*/div[@class="first_block"]/'
        'div[@class="form-group third_class"]/input'
    )
    phone = browser.find_element_by_xpath(
        '//*/div[@class="second_block"]/'
        'div[@class="form-group first_class"]/input'
    )
    address = browser.find_element_by_xpath(
        '//*/div[@class="second_block"]/'
        'div[@class="form-group second_class"]/input'
    )
    first_name.send_keys('Bob')
    last_name.send_keys('Ross')
    email.send_keys('BobRoss@mail.com')
    phone.send_keys('123456789')
    address.send_keys('LA, Grove st. 5')
    browser.save_screenshot(
        f'screenshot_{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}.png'
    )
    #
    button = browser.find_element_by_css_selector("button.btn")
    button.click()
    time.sleep(1)
    welcome_text_elt = browser.find_element_by_tag_name("h1")
    welcome_text = welcome_text_elt.text
    browser.save_screenshot(
        f'screenshot_{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}.png'
    )
    assert "Congratulations! You have successfully registered!" == welcome_text

finally:
    time.sleep(30)
    browser.quit()
